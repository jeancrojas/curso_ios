//
//  ClasificacionGlobalTableViewController.h
//  Quiz
//
//  Created by cice on 10/3/17.
//  Copyright © 2017 scriptingsystems. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClasificacionGlobalTableViewController : UITableViewController

@end
