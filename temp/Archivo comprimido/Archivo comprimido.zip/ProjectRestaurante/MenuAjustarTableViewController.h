//
//  MenuAjustarTableViewController.h
//  ProjectRestaurante
//
//  Created by cice on 27/3/17.
//  Copyright © 2017 scriptingsystems. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuAjustarTableViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UILabel *labelEntrantesMenuAjustarTVC;
@property (weak, nonatomic) IBOutlet UILabel *labelPrincipalesMenuAjustarTVC;
@property (weak, nonatomic) IBOutlet UILabel *labelPostresMenuAjustarTVC;
@property (weak, nonatomic) IBOutlet UILabel *labelBebidasMenuAjustarTVC;

@end
