//
//  PlatoPedidoTableViewController.h
//  ProjectRestaurante
//
//  Created by cice on 31/3/17.
//  Copyright © 2017 scriptingsystems. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlatoPedidoTableViewController : UITableViewController

@end
