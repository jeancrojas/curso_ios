//
//  AjustarTableViewController.h
//  ProjectRestaurante
//
//  Created by cice on 24/3/17.
//  Copyright © 2017 scriptingsystems. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AjustarTableViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UILabel *labelMesaAjustarTVC;
@property (weak, nonatomic) IBOutlet UILabel *labelMenuAjustarTVC;
@property (weak, nonatomic) IBOutlet UILabel *labelPlatoCartaAjustarTVC;
@property (weak, nonatomic) IBOutlet UILabel *labelBebidaAjustarTVC;
@property (weak, nonatomic) IBOutlet UILabel *labelPostreAjustarTVC;

@end
