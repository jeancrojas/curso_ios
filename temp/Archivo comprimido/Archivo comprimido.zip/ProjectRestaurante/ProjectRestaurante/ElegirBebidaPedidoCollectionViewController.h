//
//  ElegirBebidaPedidoCollectionViewController.h
//  ProjectRestaurante
//
//  Created by cice on 3/4/17.
//  Copyright © 2017 scriptingsystems. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ElegirBebidaPedidoCollectionViewController : UICollectionViewController
@property (nonatomic,assign) int categoriaBebida;

@end
