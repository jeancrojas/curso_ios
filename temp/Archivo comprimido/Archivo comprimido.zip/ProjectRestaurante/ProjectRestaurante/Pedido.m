//
//  Pedido.m
//  ProjectRestaurante
//
//  Created by cice on 5/4/17.
//  Copyright © 2017 scriptingsystems. All rights reserved.
//

#import "Pedido.h"

@implementation Pedido
@synthesize idPedido;
@synthesize fecha;
@synthesize idBebida;
@synthesize idPlato;
@synthesize precio;

@end
