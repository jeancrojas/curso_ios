//
//  ElegirPlatoPedidoCollectionViewController.h
//  ProjectRestaurante
//
//  Created by cice on 31/3/17.
//  Copyright © 2017 scriptingsystems. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ElegirPlatoPedidoCollectionViewController : UICollectionViewController
//La clase PlatoPedidoTableViewController, le da valor a esta variable segun la categoria
//del plato pescados, carnes y arroces
@property (nonatomic,assign) int categoriaPlato;

@end
